﻿namespace AutomatedTester.BrowserMob.HAR
{
    public class QueryStringItem
    {
        public string Name { get; set; }

        public string Value { get; set; }

        public string Comment { get; set; }
    }
}