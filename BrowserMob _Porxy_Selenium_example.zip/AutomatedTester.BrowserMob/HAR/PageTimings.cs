﻿namespace AutomatedTester.BrowserMob.HAR
{
    public class PageTimings
    {
        public int? OnContentLoad { get; set; }

        public int? OnLoad { get; set; }

        public string Comment { get; set; }
    }
}