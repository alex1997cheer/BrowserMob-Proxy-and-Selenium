﻿namespace AutomatedTester.BrowserMob.HAR
{
    public class Creator
    {
        public string Name { get; set; }

        public string Version { get; set; }

        public string Comment { get; set; }
    }
}