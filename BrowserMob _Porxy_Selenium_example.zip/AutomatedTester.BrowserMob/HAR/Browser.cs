﻿namespace AutomatedTester.BrowserMob.HAR
{
    public class Browser
    {
        public string Name { get; set; }
       
        public string Version { get; set; }

        public string Comment { get; set; }
    }
}