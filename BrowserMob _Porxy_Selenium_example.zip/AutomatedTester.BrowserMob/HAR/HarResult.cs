﻿namespace AutomatedTester.BrowserMob.HAR
{
    public class HarResult
    {
        public Log Log { get; set; }    
    }
}