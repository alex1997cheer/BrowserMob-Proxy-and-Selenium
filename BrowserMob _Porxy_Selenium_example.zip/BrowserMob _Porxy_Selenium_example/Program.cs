﻿using AutomatedTester.BrowserMob;
using AutomatedTester.BrowserMob.HAR;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BrowserMob__Porxy_Selenium_example
{
    class Program
    {
        static void Main(string[] args)
        {
            //BrowserMob-Proxy 
            Server server = new Server(Environment.CurrentDirectory + @"\browsermob-proxy-2.1.4\bin\browsermob-proxy.bat");
            server.Start();
            //Get proxy
            Client client = server.CreateProxy();
            client.SetCaptureContent(); //Capture netwrok responce
            //New har file
            client.NewHar();
            //sslproxy and http setting
            var seleniumProxy = new Proxy { HttpProxy = client.SeleniumProxy, SslProxy = client.SeleniumProxy };
            var options = new ChromeOptions();
            options.Proxy = seleniumProxy;
            IWebDriver driver = new ChromeDriver(Environment.CurrentDirectory, options);
            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl("https://www.baidu.com");
            Thread.Sleep(3000);
            HarResult harData = client.GetHar();
            Log log = harData.Log;
            Entry[] entries = log.Entries;
        }
    }
}
